import { API_BASE } from './config.js';

function authHeaders() {
  const token = localStorage.getItem('tvr_admin_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request(path, { method = 'GET', body, auth = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) Object.assign(headers, authHeaders());

  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (networkErr) {
    throw new Error('Could not reach the server. Check your connection and try again.');
  }

  let data = null;
  const text = await res.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }

  if (!res.ok) {
    const message = (data && data.error) || `Request failed (${res.status})`;
    const err = new Error(message);
    err.status = res.status;
    throw err;
  }
  return data;
}

export const api = {
  // Public
  getEpisodes: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/api/episodes${qs ? `?${qs}` : ''}`);
  },
  getEpisode: (id) => request(`/api/episodes/${id}`),
  getTrailer: () => request('/api/trailer'),
  getSettings: () => request('/api/settings'),
  getVoiceArtists: () => request('/api/voice-artists'),
  getComments: (episodeId) => request(`/api/comments/${episodeId}`),
  postComment: (episodeId, body) => request(`/api/comments/${episodeId}`, { method: 'POST', body }),
  getReactions: (episodeId, visitorId) =>
    request(`/api/reactions/${episodeId}?visitorId=${encodeURIComponent(visitorId)}`),
  postReaction: (episodeId, body) => request(`/api/reactions/${episodeId}`, { method: 'POST', body }),

  // Admin auth
  login: (password) => request('/api/admin/login', { method: 'POST', body: { password } }),
  verifyToken: () => request('/api/admin/verify', { auth: true }),
  changePassword: (body) => request('/api/admin/change-password', { method: 'POST', body, auth: true }),

  // Admin — episodes
  createEpisode: (body) => request('/api/episodes', { method: 'POST', body, auth: true }),
  updateEpisode: (id, body) => request(`/api/episodes/${id}`, { method: 'PUT', body, auth: true }),
  deleteEpisode: (id) => request(`/api/episodes/${id}`, { method: 'DELETE', auth: true }),

  // Admin — trailer
  saveTrailer: (body) => request('/api/trailer', { method: 'POST', body, auth: true }),

  // Admin — settings
  updateSettings: (body) => request('/api/settings', { method: 'PUT', body, auth: true }),

  // Admin — voice artists
  addVoiceArtist: (name) => request('/api/voice-artists', { method: 'POST', body: { name }, auth: true }),
  deleteVoiceArtist: (id) => request(`/api/voice-artists/${id}`, { method: 'DELETE', auth: true }),

  // Admin — comment moderation
  getAllComments: () => request('/api/admin/comments', { auth: true }),
  deleteComment: (id) => request(`/api/admin/comments/${id}`, { method: 'DELETE', auth: true }),
};
